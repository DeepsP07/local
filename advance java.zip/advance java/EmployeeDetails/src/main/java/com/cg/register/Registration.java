package com.cg.register;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class EmpRegister
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}



	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	/*protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
response.getWriter().append("Served at: ").append(request.getContextPath());
}*/



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		System.out.println("In Do Post");
		String empName=request.getParameter("myName") ;
		int employeeId=Integer.parseInt(request.getParameter("myEmpid"));
		int empSalary=Integer.parseInt(request.getParameter("mySalary"));
		String empPassword=request.getParameter("myPassword");
		String empJoindate =request.getParameter("myjoindate");
		String empDepartment =request.getParameter("empdepart");

		System.out.println("going to try");
		try {
			Class.forName("org.mysql.jdbc.Driver");
			Connection c = DriverManager
					.getConnection("jdbc:mysql://localhost:5432/empdatabase",
							"mysql", "root");
			System.out.println("Opened database successfully");



			PreparedStatement prstmt = c.prepareStatement("insert into EmployeeTable values(?,?,?,?,?,?)");

			prstmt.setInt(1, employeeId);
			prstmt.setString(2, empName);
			prstmt.setInt(3, empSalary);
			prstmt.setString(4, empDepartment);
			prstmt.setString(5, empPassword);
			prstmt.setString(6, empJoindate);


			int i=prstmt.executeUpdate();
			if(i>0) {
				out.println("registered succesfully");
			}


			c.close();
			prstmt.close();
		}
		catch(Exception e2) {e2.printStackTrace();}

	}



}